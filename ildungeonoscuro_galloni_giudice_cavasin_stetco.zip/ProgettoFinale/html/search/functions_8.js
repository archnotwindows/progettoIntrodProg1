var searchData=
[
  ['stampamenu_0',['stampamenu',['../nuovoGioco_8c.html#aafe68d574a2bf082b5b023b1416f16b2',1,'stampaMenu(bool trucchiAttivi):&#160;nuovoGioco.c'],['../nuovoGioco_8h.html#aafe68d574a2bf082b5b023b1416f16b2',1,'stampaMenu(bool trucchiAttivi):&#160;nuovoGioco.c']]]
];
