var indexSectionsWithContent =
{
  0: "_acdeghilmnoprstv",
  1: "gr",
  2: "gimnst",
  3: "aceilmnpst",
  4: "acdhimntv",
  5: "t",
  6: "t",
  7: "_dlmp",
  8: "diop"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Strutture dati",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Tipi enumerati (enum)",
  6: "Valori del tipo enumerato",
  7: "Definizioni",
  8: "Pagine"
};

