var searchData=
[
  ['list_5fcommand_0',['LIST_COMMAND',['../salvataggi_8c.html#aa976fd4a3d989ebc7783c7b241a7d287',1,'salvataggi.c']]]
];
