var searchData=
[
  ['vita_0',['vita',['../structGiocatore.html#a14c297d7049e47b7bcef2c6ea8edb671',1,'Giocatore']]]
];
