var searchData=
[
  ['listasalvataggi_0',['listasalvataggi',['../salvataggi_8c.html#adab8accc64e79b6907f8ee1ff6446bf8',1,'listaSalvataggi():&#160;salvataggi.c'],['../salvataggi_8h.html#adab8accc64e79b6907f8ee1ff6446bf8',1,'listaSalvataggi():&#160;salvataggi.c']]]
];
