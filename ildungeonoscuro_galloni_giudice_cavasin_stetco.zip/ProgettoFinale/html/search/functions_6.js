var searchData=
[
  ['negozio_0',['negozio',['../negozio_8c.html#a1d36ad6acf28cfa2ece96483d59b52c7',1,'negozio(Giocatore *giocatore_ptr):&#160;negozio.c'],['../negozio_8h.html#a1d36ad6acf28cfa2ece96483d59b52c7',1,'negozio(Giocatore *giocatore_ptr):&#160;negozio.c']]],
  ['nuovogioco_1',['nuovogioco',['../nuovoGioco_8c.html#a041cdf9de059ad67872189ce3cb0063c',1,'nuovoGioco():&#160;nuovoGioco.c'],['../nuovoGioco_8h.html#a041cdf9de059ad67872189ce3cb0063c',1,'nuovoGioco():&#160;nuovoGioco.c']]],
  ['nuovosalvataggio_2',['nuovosalvataggio',['../salvataggi_8c.html#af13b31f6b761a6b7483a9cb18af25cc4',1,'nuovoSalvataggio(Giocatore *g):&#160;salvataggi.c'],['../salvataggi_8h.html#af13b31f6b761a6b7483a9cb18af25cc4',1,'nuovoSalvataggio(Giocatore *g):&#160;salvataggi.c']]]
];
