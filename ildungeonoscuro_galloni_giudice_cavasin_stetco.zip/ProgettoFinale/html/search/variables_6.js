var searchData=
[
  ['nome_0',['nome',['../structRigaDungeon.html#aa46cc4f685541f91769d32390caba714',1,'RigaDungeon']]]
];
