var searchData=
[
  ['negozio_2ec_0',['negozio.c',['../negozio_8c.html',1,'']]],
  ['negozio_2eh_1',['negozio.h',['../negozio_8h.html',1,'']]],
  ['nuovogioco_2ec_2',['nuovoGioco.c',['../nuovoGioco_8c.html',1,'']]],
  ['nuovogioco_2eh_3',['nuovoGioco.h',['../nuovoGioco_8h.html',1,'']]]
];
