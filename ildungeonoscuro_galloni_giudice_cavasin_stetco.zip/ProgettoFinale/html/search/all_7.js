var searchData=
[
  ['il_20dungeon_20oscuro_0',['Documentazione del progetto &quot;Il Dungeon Oscuro&quot;',['../index.html',1,'']]],
  ['introduzione_1',['Introduzione',['../index.html#intro_sec',1,'']]],
  ['inventario_2',['inventario',['../inventario_8c.html#a40e46221259810317ca7fa8b2bcf8de6',1,'Inventario(Giocatore *g):&#160;inventario.c'],['../inventario_8h.html#a40e46221259810317ca7fa8b2bcf8de6',1,'Inventario(Giocatore *g):&#160;inventario.c']]],
  ['inventario_2ec_3',['inventario.c',['../inventario_8c.html',1,'']]],
  ['inventario_2eh_4',['inventario.h',['../inventario_8h.html',1,'']]],
  ['is_5fobiettivo_5',['is_obiettivo',['../structRigaDungeon.html#abf798a980ee9622bed01985e80b1887d',1,'RigaDungeon']]]
];
