var searchData=
[
  ['main_0',['main',['../main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.c']]],
  ['menu_1',['menu',['../menuMissioni_8c.html#a1edc1f6ccd27be94e77587555e26e100',1,'Menu(Giocatore *giocatore_ptr):&#160;menuMissioni.c'],['../menuMissioni_8h.html#a1edc1f6ccd27be94e77587555e26e100',1,'Menu(Giocatore *giocatore_ptr):&#160;menuMissioni.c']]],
  ['menuvillaggio_2',['menuvillaggio',['../menuvillaggio_8c.html#accd456c6d700c06e4ff1309d14d25ea3',1,'menuVillaggio(Giocatore *giocatore_ptr):&#160;menuvillaggio.c'],['../menuvillaggio_8h.html#accd456c6d700c06e4ff1309d14d25ea3',1,'menuVillaggio(Giocatore *giocatore_ptr):&#160;menuvillaggio.c']]],
  ['modificasalvataggio_3',['modificasalvataggio',['../salvataggi_8c.html#adf592ebbc9d338383dbb7ef8d921840a',1,'modificaSalvataggio(int numeroSalvataggio):&#160;salvataggi.c'],['../salvataggi_8h.html#adcbe1cec44c829d397f5130a8204f18b',1,'modificaSalvataggio(int n):&#160;salvataggi.c']]],
  ['mossarandom_4',['mossarandom',['../missionefinale_8c.html#a4fdcb5d7028fdec314942a9c3e6bd519',1,'missionefinale.c']]]
];
