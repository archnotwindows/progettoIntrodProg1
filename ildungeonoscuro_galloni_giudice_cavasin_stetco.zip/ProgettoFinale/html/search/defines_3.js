var searchData=
[
  ['mkdir_0',['MKDIR',['../salvataggi_8c.html#a17cda852a890b03845a49ff1a8ae7f6d',1,'salvataggi.c']]]
];
