var searchData=
[
  ['rigadungeon_0',['RigaDungeon',['../structRigaDungeon.html',1,'']]]
];
