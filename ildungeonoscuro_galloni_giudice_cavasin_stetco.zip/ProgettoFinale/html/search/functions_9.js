var searchData=
[
  ['trigghertrucchi_0',['trigghertrucchi',['../salvataggi_8c.html#a0b197621f869405211a8975e3d56e5f9',1,'triggherTrucchi(char tasto):&#160;salvataggi.c'],['../salvataggi_8h.html#a0b197621f869405211a8975e3d56e5f9',1,'triggherTrucchi(char tasto):&#160;salvataggi.c']]]
];
