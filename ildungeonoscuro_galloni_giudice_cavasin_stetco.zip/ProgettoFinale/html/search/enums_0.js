var searchData=
[
  ['tipostanza_0',['TipoStanza',['../tabellemissioni_8h.html#a345e14e9a00bab462630bf1978aa24a6',1,'tabellemissioni.h']]]
];
