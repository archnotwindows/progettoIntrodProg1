var searchData=
[
  ['is_5fobiettivo_0',['is_obiettivo',['../structRigaDungeon.html#abf798a980ee9622bed01985e80b1887d',1,'RigaDungeon']]]
];
