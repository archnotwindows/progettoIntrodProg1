var searchData=
[
  ['padovan_0',['padovan',['../missione3espdun_8c.html#ae7c83e4d97d50567cda5b807d89d6652',1,'missione3espdun.c']]],
  ['puliscischermo_1',['puliscischermo',['../systemclear_8c.html#ab829d2cf08617f155740c0d6876979b4',1,'puliscischermo():&#160;systemclear.c'],['../systemclear_8h.html#ab829d2cf08617f155740c0d6876979b4',1,'puliscischermo():&#160;systemclear.c']]]
];
