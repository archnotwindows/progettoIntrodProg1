var searchData=
[
  ['dir_5fseparator_0',['DIR_SEPARATOR',['../salvataggi_8c.html#a0920890c442b665b0c6609fa796e9047',1,'salvataggi.c']]]
];
