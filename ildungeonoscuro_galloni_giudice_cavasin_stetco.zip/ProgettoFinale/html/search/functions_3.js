var searchData=
[
  ['inventario_0',['inventario',['../inventario_8c.html#a40e46221259810317ca7fa8b2bcf8de6',1,'Inventario(Giocatore *g):&#160;inventario.c'],['../inventario_8h.html#a40e46221259810317ca7fa8b2bcf8de6',1,'Inventario(Giocatore *g):&#160;inventario.c']]]
];
