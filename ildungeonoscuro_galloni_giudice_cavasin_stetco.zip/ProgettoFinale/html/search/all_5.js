var searchData=
[
  ['giocatore_0',['Giocatore',['../structGiocatore.html',1,'']]],
  ['giocatore_2eh_1',['giocatore.h',['../giocatore_8h.html',1,'']]]
];
