var searchData=
[
  ['attacco_0',['attacco',['../structGiocatore.html#a7ffeb3f1ffac95caed7c09d7bdb04120',1,'Giocatore']]]
];
