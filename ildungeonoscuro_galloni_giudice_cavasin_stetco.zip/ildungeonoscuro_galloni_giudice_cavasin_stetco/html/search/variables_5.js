var searchData=
[
  ['missione_5fgrotta_5fcompletata_0',['missione_grotta_completata',['../structGiocatore.html#a4707e2431224a0979956e34c315dedde',1,'Giocatore']]],
  ['missione_5fmagione_5fcompletata_1',['missione_magione_completata',['../structGiocatore.html#a049460b9c8897599427772765c9eab19',1,'Giocatore']]],
  ['missione_5fpalude_5fcompletata_2',['missione_palude_completata',['../structGiocatore.html#a9e837a7d17050ff446df6616e07f84c3',1,'Giocatore']]],
  ['monete_3',['monete',['../structGiocatore.html#ab16e84c52ef3c289fda14fd416f31a47',1,'Giocatore::monete'],['../structRigaDungeon.html#a7e6cdf8468743f5d0cc1f50c46927d0d',1,'RigaDungeon::monete']]]
];
