var searchData=
[
  ['salvataggi_2ec_0',['salvataggi.c',['../salvataggi_8c.html',1,'']]],
  ['salvataggi_2eh_1',['salvataggi.h',['../salvataggi_8h.html',1,'']]],
  ['stampamenu_2',['stampamenu',['../nuovoGioco_8c.html#aafe68d574a2bf082b5b023b1416f16b2',1,'stampaMenu(bool trucchiAttivi):&#160;nuovoGioco.c'],['../nuovoGioco_8h.html#aafe68d574a2bf082b5b023b1416f16b2',1,'stampaMenu(bool trucchiAttivi):&#160;nuovoGioco.c']]],
  ['systemclear_2ec_3',['systemclear.c',['../systemclear_8c.html',1,'']]],
  ['systemclear_2eh_4',['systemclear.h',['../systemclear_8h.html',1,'']]]
];
