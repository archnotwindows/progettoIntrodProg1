var searchData=
[
  ['colpo_5ffatale_0',['colpo_fatale',['../structRigaDungeon.html#a7d2440d227290f2f3e5e91360438099f',1,'RigaDungeon']]]
];
