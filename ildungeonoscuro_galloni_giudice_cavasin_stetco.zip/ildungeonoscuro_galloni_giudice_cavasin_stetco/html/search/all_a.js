var searchData=
[
  ['negozio_0',['negozio',['../negozio_8c.html#a1d36ad6acf28cfa2ece96483d59b52c7',1,'negozio(Giocatore *giocatore_ptr):&#160;negozio.c'],['../negozio_8h.html#a1d36ad6acf28cfa2ece96483d59b52c7',1,'negozio(Giocatore *giocatore_ptr):&#160;negozio.c']]],
  ['negozio_2ec_1',['negozio.c',['../negozio_8c.html',1,'']]],
  ['negozio_2eh_2',['negozio.h',['../negozio_8h.html',1,'']]],
  ['nome_3',['nome',['../structRigaDungeon.html#aa46cc4f685541f91769d32390caba714',1,'RigaDungeon']]],
  ['nuovogioco_4',['nuovogioco',['../nuovoGioco_8c.html#a041cdf9de059ad67872189ce3cb0063c',1,'nuovoGioco():&#160;nuovoGioco.c'],['../nuovoGioco_8h.html#a041cdf9de059ad67872189ce3cb0063c',1,'nuovoGioco():&#160;nuovoGioco.c']]],
  ['nuovogioco_2ec_5',['nuovoGioco.c',['../nuovoGioco_8c.html',1,'']]],
  ['nuovogioco_2eh_6',['nuovoGioco.h',['../nuovoGioco_8h.html',1,'']]],
  ['nuovosalvataggio_7',['nuovosalvataggio',['../salvataggi_8c.html#af13b31f6b761a6b7483a9cb18af25cc4',1,'nuovoSalvataggio(Giocatore *g):&#160;salvataggi.c'],['../salvataggi_8h.html#af13b31f6b761a6b7483a9cb18af25cc4',1,'nuovoSalvataggio(Giocatore *g):&#160;salvataggi.c']]]
];
