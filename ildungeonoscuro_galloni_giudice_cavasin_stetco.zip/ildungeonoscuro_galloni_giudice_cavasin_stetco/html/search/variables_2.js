var searchData=
[
  ['danno_0',['danno',['../structRigaDungeon.html#ad70e9608eecbae07dae952bd7c367c5f',1,'RigaDungeon']]]
];
