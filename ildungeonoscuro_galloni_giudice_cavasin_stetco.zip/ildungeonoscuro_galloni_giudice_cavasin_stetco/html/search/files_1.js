var searchData=
[
  ['inventario_2ec_0',['inventario.c',['../inventario_8c.html',1,'']]],
  ['inventario_2eh_1',['inventario.h',['../inventario_8h.html',1,'']]]
];
