var searchData=
[
  ['list_5fcommand_0',['LIST_COMMAND',['../salvataggi_8c.html#aa976fd4a3d989ebc7783c7b241a7d287',1,'salvataggi.c']]],
  ['listasalvataggi_1',['listasalvataggi',['../salvataggi_8c.html#adab8accc64e79b6907f8ee1ff6446bf8',1,'listaSalvataggi():&#160;salvataggi.c'],['../salvataggi_8h.html#adab8accc64e79b6907f8ee1ff6446bf8',1,'listaSalvataggi():&#160;salvataggi.c']]]
];
