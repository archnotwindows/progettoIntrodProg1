var searchData=
[
  ['salvataggi_2ec_0',['salvataggi.c',['../salvataggi_8c.html',1,'']]],
  ['salvataggi_2eh_1',['salvataggi.h',['../salvataggi_8h.html',1,'']]],
  ['systemclear_2ec_2',['systemclear.c',['../systemclear_8c.html',1,'']]],
  ['systemclear_2eh_3',['systemclear.h',['../systemclear_8h.html',1,'']]]
];
