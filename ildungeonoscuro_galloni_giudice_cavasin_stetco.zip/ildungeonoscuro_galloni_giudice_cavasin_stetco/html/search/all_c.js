var searchData=
[
  ['padovan_0',['padovan',['../missione3espdun_8c.html#ae7c83e4d97d50567cda5b807d89d6652',1,'missione3espdun.c']]],
  ['pclose_1',['PCLOSE',['../salvataggi_8c.html#a4c39c7c96d7f5d1f5cd1743122d476e3',1,'salvataggi.c']]],
  ['popen_2',['POPEN',['../salvataggi_8c.html#ab6949e8178edeb4294d893f3ee4966d5',1,'salvataggi.c']]],
  ['progetto_20il_20dungeon_20oscuro_3',['Documentazione del progetto &quot;Il Dungeon Oscuro&quot;',['../index.html',1,'']]],
  ['puliscischermo_4',['puliscischermo',['../systemclear_8c.html#ab829d2cf08617f155740c0d6876979b4',1,'puliscischermo():&#160;systemclear.c'],['../systemclear_8h.html#ab829d2cf08617f155740c0d6876979b4',1,'puliscischermo():&#160;systemclear.c']]]
];
