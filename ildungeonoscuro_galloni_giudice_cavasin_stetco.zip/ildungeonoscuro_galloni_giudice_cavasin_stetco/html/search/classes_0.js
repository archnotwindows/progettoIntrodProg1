var searchData=
[
  ['giocatore_0',['Giocatore',['../structGiocatore.html',1,'']]]
];
