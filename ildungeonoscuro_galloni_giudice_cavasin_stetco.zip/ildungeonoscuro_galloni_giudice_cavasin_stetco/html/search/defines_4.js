var searchData=
[
  ['pclose_0',['PCLOSE',['../salvataggi_8c.html#a4c39c7c96d7f5d1f5cd1743122d476e3',1,'salvataggi.c']]],
  ['popen_1',['POPEN',['../salvataggi_8c.html#ab6949e8178edeb4294d893f3ee4966d5',1,'salvataggi.c']]]
];
