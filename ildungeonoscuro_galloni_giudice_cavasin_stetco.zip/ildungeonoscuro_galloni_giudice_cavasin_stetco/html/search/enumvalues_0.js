var searchData=
[
  ['tipo_5fcombattimento_0',['TIPO_COMBATTIMENTO',['../tabellemissioni_8h.html#a345e14e9a00bab462630bf1978aa24a6a62bb17a3d4493e4591a0eca9fe950a48',1,'tabellemissioni.h']]],
  ['tipo_5ftrappola_1',['TIPO_TRAPPOLA',['../tabellemissioni_8h.html#a345e14e9a00bab462630bf1978aa24a6a91c6a40e503d3b869c3f40038da08459',1,'tabellemissioni.h']]],
  ['tipo_5fvuota_2',['TIPO_VUOTA',['../tabellemissioni_8h.html#a345e14e9a00bab462630bf1978aa24a6a5eab80387c498186427f91a3c2810a6a',1,'tabellemissioni.h']]]
];
