var searchData=
[
  ['caricadatisalvataggio_0',['caricadatisalvataggio',['../salvataggi_8c.html#a1912cd89ae44ef137420b207769f3632',1,'caricaDatiSalvataggio(int numeroSalvataggio, Giocatore *g):&#160;salvataggi.c'],['../salvataggi_8h.html#ae79c8c63dfe9c92a31b7f08dcc2a5682',1,'caricaDatiSalvataggio(int n, Giocatore *g):&#160;salvataggi.c']]],
  ['checkdirsalvataggi_1',['checkDirSalvataggi',['../salvataggi_8c.html#a3453e09dde07013ea2ca1146020bb6a7',1,'salvataggi.c']]],
  ['combattimentofinale_2',['combattimentofinale',['../missionefinale_8c.html#a3ad4bbf8b478f335815a9688e70a3099',1,'CombattimentoFinale(Giocatore *g):&#160;missionefinale.c'],['../missionefinale_8h.html#a3ad4bbf8b478f335815a9688e70a3099',1,'CombattimentoFinale(Giocatore *g):&#160;missionefinale.c']]]
];
