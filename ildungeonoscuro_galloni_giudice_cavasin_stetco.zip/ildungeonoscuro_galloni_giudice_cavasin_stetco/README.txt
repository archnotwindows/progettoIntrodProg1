Nome Gruppo: il dungeon oscuro

Componenti gruppo:
 - Lorenzo Galloni      matricola n° 910964
 - Lorenzo Giudice      matricola n° 909285
 - Elia Cavasin         matricola n° 910668
 - Denis Stetco         matricola n° 912655